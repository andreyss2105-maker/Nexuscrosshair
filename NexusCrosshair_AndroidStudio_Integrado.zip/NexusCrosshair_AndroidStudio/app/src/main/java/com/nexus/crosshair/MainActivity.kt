package com.nexus.crosshair

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private var shape = "DOT"
    private var color = Color.RED
    private var crosshairSize = 24
    private var opacity = 230
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 24)
            setBackgroundColor(Color.rgb(7, 26, 43))
        }

        val title = TextView(this).apply {
            text = "NEXUS CROSSHAIR"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val subtitle = TextView(this).apply {
            text = "Mira visual flutuante"
            textSize = 14f
            setTextColor(Color.rgb(170, 190, 210))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        root.addView(subtitle)

        root.addView(sectionTitle("Formato da mira"))
        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val dot = RadioButton(this).apply { text = "Bolinha"; id = View.generateViewId(); isChecked = true; setTextColor(Color.WHITE) }
        val cross = RadioButton(this).apply { text = "X"; id = View.generateViewId(); setTextColor(Color.WHITE) }
        group.addView(dot); group.addView(cross)
        group.setOnCheckedChangeListener { _, checkedId -> shape = if (checkedId == cross.id) "X" else "DOT" }
        root.addView(group)

        root.addView(sectionTitle("Cor"))
        val colorSpinner = Spinner(this)
        val names = listOf("Vermelho", "Branco", "Verde", "Amarelo", "Ciano")
        colorSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        colorSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                color = listOf(Color.RED, Color.WHITE, Color.GREEN, Color.YELLOW, Color.CYAN)[position]
            }
        }
        root.addView(colorSpinner)

        val sizeLabel = sectionTitle("Tamanho: 24")
        root.addView(sizeLabel)
        val sizeBar = SeekBar(this).apply { max = 50; progress = 18 }
        sizeBar.setOnSeekBarChangeListener(listener { progress ->
            crosshairSize = progress + 6
            sizeLabel.text = "Tamanho: $crosshairSize"
        })
        root.addView(sizeBar)

        val opacityLabel = sectionTitle("Transparência: 90%")
        root.addView(opacityLabel)
        val alphaBar = SeekBar(this).apply { max = 100; progress = 90 }
        alphaBar.setOnSeekBarChangeListener(listener { progress ->
            opacity = (progress.coerceAtLeast(10) * 255) / 100
            opacityLabel.text = "Transparência: ${progress.coerceAtLeast(10)}%"
        })
        root.addView(alphaBar)

        val activate = Button(this).apply {
            text = "ATIVAR / ATUALIZAR MIRA"
            setOnClickListener { startOverlay() }
        }
        root.addView(activate, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 24 })

        val deactivate = Button(this).apply {
            text = "DESATIVAR MIRA"
            setOnClickListener {
                startService(Intent(this@MainActivity, CrosshairService::class.java).setAction(CrosshairService.ACTION_HIDE))
                status.text = "Mira desativada."
            }
        }
        root.addView(deactivate, LinearLayout.LayoutParams(-1, -2))

        status = TextView(this).apply {
            text = "A mira ficará centralizada enquanto o serviço estiver ativo."
            textSize = 12f
            setTextColor(Color.rgb(112, 229, 206))
            setPadding(0, 18, 0, 8)
        }
        root.addView(status)

        val note = TextView(this).apply {
            text = "O Android exige permissão para aparecer sobre outros apps. Uma notificação persistente indica quando a mira está ativa. O app não controla nem modifica o Free Fire."
            textSize = 12f
            setTextColor(Color.rgb(170, 190, 210))
        }
        root.addView(note)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(Color.rgb(220, 235, 245))
        setPadding(0, 18, 0, 5)
    }

    private fun listener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = onChange(progress)
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Conceda a permissão e depois toque em ATIVAR novamente."
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val intent = Intent(this, CrosshairService::class.java).apply {
            action = CrosshairService.ACTION_SHOW
            putExtra(CrosshairService.EXTRA_SHAPE, shape)
            putExtra(CrosshairService.EXTRA_COLOR, color)
            putExtra(CrosshairService.EXTRA_SIZE, crosshairSize)
            putExtra(CrosshairService.EXTRA_ALPHA, opacity)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        status.text = "Mira ativada/atualizada. Ela está centralizada na tela."
    }
}
