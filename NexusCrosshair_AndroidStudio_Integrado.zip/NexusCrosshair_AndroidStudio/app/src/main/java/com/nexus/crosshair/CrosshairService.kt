package com.nexus.crosshair

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class CrosshairService : Service() {
    companion object {
        const val ACTION_SHOW = "com.nexus.crosshair.SHOW"
        const val ACTION_HIDE = "com.nexus.crosshair.HIDE"
        const val EXTRA_SHAPE = "shape"
        const val EXTRA_COLOR = "color"
        const val EXTRA_SIZE = "size"
        const val EXTRA_ALPHA = "alpha"
        private const val CHANNEL_ID = "nexus_crosshair_channel"
        private const val NOTIFICATION_ID = 1201
    }

    private lateinit var windowManager: WindowManager
    private var overlay: CrosshairView? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_HIDE -> {
                removeOverlay()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SHOW -> {
                val notification = buildNotification()
                startForeground(NOTIFICATION_ID, notification)
                val shape = intent.getStringExtra(EXTRA_SHAPE) ?: "DOT"
                val color = intent.getIntExtra(EXTRA_COLOR, android.graphics.Color.RED)
                val size = intent.getIntExtra(EXTRA_SIZE, 24)
                val alpha = intent.getIntExtra(EXTRA_ALPHA, 230)
                showOverlay(shape, color, size, alpha)
            }
        }
        return START_STICKY
    }

    private fun showOverlay(shape: String, color: Int, size: Int, alpha: Int) {
        removeOverlay()
        val view = CrosshairView(this, shape, color, size, alpha)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }
        overlay = view
        windowManager.addView(view, params)
    }

    private fun removeOverlay() {
        overlay?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        overlay = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Nexus Crosshair", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Indica que a mira flutuante está ativa"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder
            .setSmallIcon(android.R.drawable.ic_menu_crop)
            .setContentTitle("Nexus Crosshair ativo")
            .setContentText("A mira visual está centralizada. Abra o app para desativar.")
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private class CrosshairView(
        context: Context,
        private val shape: String,
        color: Int,
        private val size: Int,
        alpha: Int
    ) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.alpha = alpha.coerceIn(10, 255)
            strokeWidth = 4f
            strokeCap = Paint.Cap.ROUND
            style = Paint.Style.STROKE
        }
        private val extent = (size * 2 + 16).toFloat()

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val dimension = extent.toInt()
            setMeasuredDimension(dimension, dimension)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            if (shape == "X") {
                val r = size.toFloat() / 2f
                canvas.drawLine(cx - r, cy - r, cx + r, cy + r, paint)
                canvas.drawLine(cx - r, cy + r, cx + r, cy - r, paint)
            } else {
                canvas.drawCircle(cx, cy, size / 2f, paint)
            }
        }
    }
}
